CREATE VIEW order_view AS
  SELECT
    `o`.`id`           AS `order_id`,
    `o`.`venue_id`     AS `venue_id`,
    (SELECT `assets`.`orders`.`venue_id`
     FROM `assets`.`orders`
     WHERE `assets`.`orders`.`id` = `o`.`parent_order`
     LIMIT 1)          AS `parent_venue_id`,
    `o`.`owner_id`     AS `owner_id`,
    `o`.`parent_order` AS `parent_order`,
    `od`.`id`          AS `order_detail_id`,
    `od`.`asset_id`    AS `asset_id`,
    `od`.`asset_count` AS `asset_count`,
    `od`.`serial_no`   AS `serial_no`,
    `od`.`status`      AS `status`,
    `od`.`received`    AS `received`,
    `od`.`rec_type`    AS `rec_type`,
    `od`.`descp`       AS `descp`,
    `u`.`name`         AS `user_name`,
    `v`.`vname`        AS `vname`,
    `a`.`asset_name`   AS `asset_name`,
    `od`.`created_at`  AS `order_detail_created_at`
  FROM ((((`assets`.`orders` `o`
    JOIN `assets`.`order_detail` `od` ON (`o`.`id` = `od`.`order_id`)) JOIN `assets`.`users` `u`
      ON (`o`.`owner_id` = `u`.`id`)) JOIN `assets`.`venues` `v` ON (`o`.`venue_id` = `v`.`id`)) JOIN
    `assets`.`assets` `a` ON (`od`.`asset_id` = `a`.`id`))
  ORDER BY `o`.`id`;

