CREATE VIEW turn_over_summery_view AS
  SELECT
    `order_init_view`.`venue_id`    AS `venue_id`,
    `order_init_view`.`asset_id`    AS `asset_id`,
    `order_init_view`.`asset_count` AS `asset_count`
  FROM `assets`.`order_init_view`
  UNION ALL SELECT
              `order_sent_view`.`venue_id`         AS `venue_id`,
              `order_sent_view`.`asset_id`         AS `asset_id`,
              `order_sent_view`.`asset_count` * -1 AS `asset_count*-1`
            FROM `assets`.`order_sent_view`
  UNION ALL SELECT
              `order_received_view`.`paret_venue` AS `paret_venue`,
              `order_received_view`.`asset_id`    AS `asset_id`,
              `order_received_view`.`asset_count` AS `asset_count`
            FROM `assets`.`order_received_view`;

