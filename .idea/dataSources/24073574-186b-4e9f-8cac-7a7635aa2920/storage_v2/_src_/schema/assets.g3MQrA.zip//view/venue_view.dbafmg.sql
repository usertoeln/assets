CREATE VIEW venue_view AS
  SELECT
    `v`.`id`      AS `venue_id`,
    `c`.`id`      AS `city_id`,
    `v`.`vname`   AS `vname`,
    `v`.`status`  AS `status`,
    `c`.`en_name` AS `city_name`
  FROM (`assets`.`venues` `v`
    JOIN `assets`.`cities` `c` ON (`v`.`city_id` = `c`.`id`));

