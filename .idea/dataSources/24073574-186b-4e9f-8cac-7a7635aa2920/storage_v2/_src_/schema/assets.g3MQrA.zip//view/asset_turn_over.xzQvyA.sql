CREATE VIEW asset_turn_over AS
  SELECT
    `asset_turn_over_init`.`order_id`        AS `order_id`,
    `asset_turn_over_init`.`order_detail_id` AS `order_detail_id`,
    `asset_turn_over_init`.`asset_id`        AS `asset_id`,
    `asset_turn_over_init`.`asset_count`     AS `asset_count`,
    `asset_turn_over_init`.`venue_id`        AS `venue_id`
  FROM `assets`.`asset_turn_over_init`
  UNION ALL SELECT
              `asset_turn_over_receive`.`order_id`        AS `order_id`,
              `asset_turn_over_receive`.`order_detail_id` AS `order_detail_id`,
              `asset_turn_over_receive`.`asset_id`        AS `asset_id`,
              `asset_turn_over_receive`.`asset_count`     AS `asset_count`,
              `asset_turn_over_receive`.`venue_id`        AS `venue_id`
            FROM `assets`.`asset_turn_over_receive`
  UNION ALL SELECT
              `asset_turn_over_sent`.`order_id`         AS `order_id`,
              `asset_turn_over_sent`.`order_detail_id`  AS `order_detail_id`,
              `asset_turn_over_sent`.`asset_id`         AS `asset_id`,
              `asset_turn_over_sent`.`asset_count` * -1 AS `asset_count*-1`,
              `asset_turn_over_sent`.`venue_id`         AS `venue_id`
            FROM `assets`.`asset_turn_over_sent`;

