CREATE VIEW asset_turn_over_report AS
  SELECT
    `t`.`order_id`                AS `order_id`,
    `t`.`order_detail_id`         AS `order_detail_id`,
    `t`.`asset_id`                AS `asset_id`,
    `t`.`venue_id`                AS `venue_id`,
    `t`.`asset_count`             AS `asset_count`,
    `o`.`serial_no`               AS `serial_no`,
    `o`.`received`                AS `received`,
    `o`.`rec_type`                AS `rec_type`,
    `o`.`status`                  AS `status`,
    `o`.`order_detail_created_at` AS `order_detail_created_at`,
    `v`.`vname`                   AS `vname`,
    `o`.`asset_name`              AS `asset_name`
  FROM ((`assets`.`asset_turn_over` `t`
    JOIN `assets`.`order_view` `o` ON (`t`.`order_id` = `o`.`order_id`)) JOIN `assets`.`venue_view` `v`
      ON (`t`.`venue_id` = `v`.`venue_id`));

