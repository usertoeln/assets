CREATE VIEW mojodi AS
  SELECT
    `ov`.`venue_id`         AS `venue_id`,
    `ov`.`vname`            AS `vname`,
    `ov`.`asset_id`         AS `asset_id`,
    `ov`.`asset_name`       AS `asset_name`,
    `a`.`brand`             AS `brand`,
    `a`.`color`             AS `color`,
    sum(`ov`.`asset_count`) AS `asset_count`
  FROM (`assets`.`order_view` `ov`
    JOIN `assets`.`assets` `a` ON (`ov`.`asset_id` = `a`.`id`))
  WHERE `ov`.`status` = 6
  GROUP BY `ov`.`venue_id`, `ov`.`asset_id`, `a`.`brand`, `ov`.`asset_name`, `a`.`brand`, `a`.`color`
  ORDER BY `ov`.`venue_id`, `ov`.`asset_name`;

