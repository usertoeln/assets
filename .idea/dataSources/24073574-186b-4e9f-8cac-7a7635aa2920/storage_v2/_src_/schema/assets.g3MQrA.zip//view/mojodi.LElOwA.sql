CREATE VIEW mojodi AS
  SELECT
    `mo`.`venue_id`         AS `venue_id`,
    `v`.`vname`             AS `vname`,
    `a`.`asset_name`        AS `asset_name`,
    `a`.`brand`             AS `brand`,
    `a`.`color`             AS `color`,
    `a`.`spec`              AS `spec`,
    `mo`.`asset_id`         AS `asset_id`,
    sum(`mo`.`asset_count`) AS `asset_count`
  FROM ((`assets`.`turn_over_summery_view` `mo`
    JOIN `assets`.`venues` `v` ON (`mo`.`venue_id` = `v`.`id`)) JOIN `assets`.`assets` `a`
      ON (`mo`.`asset_id` = `a`.`id`))
  GROUP BY `mo`.`venue_id`, `mo`.`asset_id`, `v`.`vname`, `a`.`asset_name`, `a`.`brand`, `a`.`color`, `a`.`spec`;

