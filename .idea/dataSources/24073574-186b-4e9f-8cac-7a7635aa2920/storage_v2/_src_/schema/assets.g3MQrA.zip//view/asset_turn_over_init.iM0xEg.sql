CREATE VIEW asset_turn_over_init AS
  SELECT
    `order_view`.`order_id`        AS `order_id`,
    `order_view`.`order_detail_id` AS `order_detail_id`,
    `order_view`.`asset_id`        AS `asset_id`,
    `order_view`.`asset_count`     AS `asset_count`,
    `order_view`.`venue_id`        AS `venue_id`
  FROM `assets`.`order_view`
  WHERE `order_view`.`rec_type` = 'init' AND `order_view`.`status` = 6;

