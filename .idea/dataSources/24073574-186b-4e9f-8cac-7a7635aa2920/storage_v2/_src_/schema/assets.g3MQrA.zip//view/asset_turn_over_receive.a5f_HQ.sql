CREATE VIEW asset_turn_over_receive AS
  SELECT
    `order_view`.`order_id`        AS `order_id`,
    `order_view`.`order_detail_id` AS `order_detail_id`,
    `order_view`.`asset_id`        AS `asset_id`,
    `order_view`.`asset_count`     AS `asset_count`,
    `order_view`.`parent_venue_id` AS `venue_id`
  FROM `assets`.`order_view`
  WHERE
    `order_view`.`rec_type` = 'credit' AND `order_view`.`status` = 4 AND `order_view`.`parent_venue_id` IS NOT NULL AND
    `order_view`.`received` IS NOT NULL;

