CREATE VIEW order_received_view AS
  SELECT
    `ov`.`status`                                        AS `status`,
    `ov`.`rec_type`                                      AS `rec_type`,
    `ov`.`venue_id`                                      AS `venue_id`,
    (SELECT `assets`.`orders`.`venue_id`
     FROM `assets`.`orders`
     WHERE `assets`.`orders`.`id` = `ov`.`parent_order`) AS `paret_venue`,
    `ov`.`asset_count`                                   AS `asset_count`,
    `ov`.`received`                                      AS `received`,
    `ov`.`asset_id`                                      AS `asset_id`
  FROM (`assets`.`order_view` `ov`
    JOIN `assets`.`assets` `a` ON (`ov`.`asset_id` = `a`.`id`))
  WHERE `ov`.`status` = 4 AND `ov`.`rec_type` = 'credit' AND `ov`.`received` IS NOT NULL;

